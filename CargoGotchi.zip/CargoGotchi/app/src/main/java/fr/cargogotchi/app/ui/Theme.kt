package fr.cargogotchi.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Album d'autocollants rétro : bleu nuit, orange vif, turquoise, jaune moutarde.
val Night = Color(0xFF1E2A44)
val Panel = Color(0xFF2C3A5C)
val Orange = Color(0xFFFF6B35)
val Teal = Color(0xFF2EC4B6)
val Mustard = Color(0xFFFFD23F)
val Paper = Color(0xFFFDF6E3)

private val Scheme = darkColorScheme(
    primary = Orange,
    onPrimary = Color.Black,
    secondary = Teal,
    onSecondary = Color.Black,
    tertiary = Mustard,
    background = Night,
    onBackground = Paper,
    surface = Panel,
    onSurface = Paper,
    surfaceVariant = Panel,
    onSurfaceVariant = Paper
)

@Composable
fun CargoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
