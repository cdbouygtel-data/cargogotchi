package fr.cargogotchi.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.cargogotchi.app.data.Catalog
import fr.cargogotchi.app.data.Crado
import fr.cargogotchi.app.data.GameRepo
import fr.cargogotchi.app.data.Rarity

@Composable
fun CollectionScreen() {
    val owned by GameRepo.owned.collectAsState()
    var selected by remember { mutableStateOf<Crado?>(null) }
    val found = Catalog.cards.count { (owned[it.id] ?: 0) > 0 }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(top = 16.dp, bottom = 4.dp)) {
                Text("Collection", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Orange)
                Text("$found / ${Catalog.cards.size} cartes", color = Mustard, fontWeight = FontWeight.Bold)
                val bySet = Rarity.values().joinToString("  ") { r ->
                    val all = Catalog.cards.filter { it.rarity == r }
                    "${r.label} ${all.count { (owned[it.id] ?: 0) > 0 }}/${all.size}"
                }
                Text(bySet, fontSize = 12.sp, color = Paper.copy(alpha = 0.7f))
            }
        }
        items(Catalog.cards, key = { it.id }) { c ->
            val n = owned[c.id] ?: 0
            CradoCardView(
                c,
                count = n,
                locked = n == 0,
                modifier = Modifier.clickable(enabled = n > 0) { selected = c }
            )
        }
    }

    selected?.let { c ->
        AlertDialog(
            onDismissRequest = { selected = null },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Fermer") } },
            title = { Text("${c.emoji} ${c.name}") },
            text = { Text("${c.rarity.label}\n\n${c.desc}") }
        )
    }
}

