package fr.cargogotchi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import fr.cargogotchi.app.ui.CargoTheme
import fr.cargogotchi.app.ui.CollectionScreen
import fr.cargogotchi.app.ui.PacksScreen
import fr.cargogotchi.app.ui.ParkingScreen
import fr.cargogotchi.app.ui.TripScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CargoTheme { AppRoot() }
        }
    }
}

private val tabs = listOf("Trajet" to "🚗", "Packs" to "🎁", "Collection" to "🃏", "Parking" to "🅿️")

@Composable
private fun AppRoot() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icon, fontSize = 22.sp) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> TripScreen(onOpenPacks = { tab = 1 })
                1 -> PacksScreen()
                2 -> CollectionScreen()
                else -> ParkingScreen()
            }
        }
    }
}
