package fr.cargogotchi.app.tracking

import fr.cargogotchi.app.data.Cargo
import fr.cargogotchi.app.data.Catalog
import kotlinx.coroutines.flow.MutableStateFlow

data class TripUi(
    val running: Boolean = false,
    val hp: Int = 100,
    val speedKmh: Int = 0,
    val distanceM: Float = 0f,
    val harshEvents: Int = 0,
    val cargo: Cargo = Catalog.cargos.first(),
    val startedAt: Long = 0L
)

/** Etat du trajet en cours, partagé entre le service et l'interface. */
object TripBus {
    val state = MutableStateFlow(TripUi())
}

fun faceFor(hp: Int): String = when {
    hp > 70 -> "😄"
    hp > 40 -> "😐"
    hp > 0 -> "😖"
    else -> "💀"
}
