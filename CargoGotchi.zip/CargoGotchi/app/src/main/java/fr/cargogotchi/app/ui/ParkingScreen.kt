package fr.cargogotchi.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import fr.cargogotchi.app.data.GameRepo
import fr.cargogotchi.app.data.ParkingSpot

@SuppressLint("MissingPermission")
private fun lastKnownLocation(ctx: Context): Location? {
    val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    if (!granted) return null
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
        .maxByOrNull { it.time }
}

@Composable
fun ParkingScreen() {
    val ctx = LocalContext.current
    val spots by GameRepo.spots.collectAsState()
    var message by remember { mutableStateOf<String?>(null) }
    var refresh by remember { mutableStateOf(0) }

    fun report() {
        val loc = lastKnownLocation(ctx)
        message = when {
            loc == null -> "Position introuvable. Active le GPS et réessaie."
            GameRepo.reportSpot(loc.latitude, loc.longitude) -> "Merci ! Place signalée. +1 pack Or."
            else -> "Patiente ${GameRepo.cooldownRemainingMs() / 60000 + 1} min avant un nouveau signalement."
        }
        refresh++
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) report() else message = "Autorise la localisation pour signaler une place."
    }

    val here = remember(refresh) { lastKnownLocation(ctx) }
    val now = System.currentTimeMillis()
    val active = spots
        .filter { now - it.reportedAt < GameRepo.SPOT_TTL_MS }
        .sortedBy { s -> here?.let { distanceTo(it, s) } ?: 0f }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Radar de parking", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Orange)

        Button(
            onClick = {
                val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                if (granted) report() else permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth().height(72.dp)
        ) {
            Text("Je libère ma place (+1 pack Or)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        message?.let { Text(it, color = Teal, fontWeight = FontWeight.Bold) }

        Text("Places signalées (moins de 20 min)", fontWeight = FontWeight.Bold)
        if (active.isEmpty()) {
            Text("Aucune place signalée pour l'instant.", color = Paper.copy(alpha = 0.7f))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(active) { s -> SpotRow(s, here, now) }
            }
        }
        Text(
            "Pour l'instant les places sont enregistrées sur ce téléphone seulement. Le partage entre joueurs demande un serveur.",
            fontSize = 12.sp,
            color = Paper.copy(alpha = 0.55f)
        )
    }
}

private fun distanceTo(from: Location, s: ParkingSpot): Float {
    val out = FloatArray(1)
    Location.distanceBetween(from.latitude, from.longitude, s.lat, s.lon, out)
    return out[0]
}

@Composable
private fun SpotRow(s: ParkingSpot, here: Location?, now: Long) {
    val ctx = LocalContext.current
    val ageMin = ((now - s.reportedAt) / 60000L).toInt()
    val dist = here?.let { distanceTo(it, s).toInt() }
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(if (dist != null) "À $dist m" else "Distance inconnue", fontWeight = FontWeight.Bold)
                Text("Signalée il y a $ageMin min", fontSize = 12.sp, color = Paper.copy(alpha = 0.7f))
            }
            OutlinedButton(onClick = {
                val uri = Uri.parse("geo:${s.lat},${s.lon}?q=${s.lat},${s.lon}(Place libre)")
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: ActivityNotFoundException) {
                    // aucune appli de cartes installée
                }
            }) { Text("Y aller") }
        }
    }
}
