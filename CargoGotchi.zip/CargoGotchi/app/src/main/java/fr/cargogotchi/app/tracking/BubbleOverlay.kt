package fr.cargogotchi.app.tracking

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

/** Bulle flottante déplaçable affichée par-dessus Waze / Google Maps. */
@SuppressLint("ClickableViewAccessibility")
class BubbleOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = ctx.resources.displayMetrics.density
    private var attached = false

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 24
        y = 320
    }

    private val view = TextView(ctx).apply {
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        val pad = (12 * density).toInt()
        setPadding(pad, pad, pad, pad)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xE61E2A44.toInt())
            setStroke((3 * density).toInt(), 0xFFFF6B35.toInt())
        }
        text = "😄\n100"

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (ev.rawX - downX).toInt()
                    params.y = startY + (ev.rawY - downY).toInt()
                    wm.updateViewLayout(v, params)
                    true
                }
                else -> false
            }
        }
    }

    fun show() {
        if (attached) return
        try {
            wm.addView(view, params)
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    fun update(face: String, cargoEmoji: String, hp: Int) {
        view.text = "$face\n$cargoEmoji $hp"
    }

    fun hide() {
        if (!attached) return
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // déjà retirée
        }
        attached = false
    }
}
