package fr.cargogotchi.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class TripResult(
    val score: Int,
    val distanceKm: Float,
    val durationMin: Int,
    val harshEvents: Int,
    val speedingSec: Int,
    val tokens: Int,
    val cargo: String,
    val endedAt: Long
)

data class ParkingSpot(val lat: Double, val lon: Double, val reportedAt: Long)

/**
 * Etat du jeu, stocké localement (SharedPreferences + JSON).
 * Le signalement de places de parking est local pour le moment : à brancher sur un backend
 * (Supabase, Firebase...) pour partager les places entre joueurs.
 */
object GameRepo {
    const val PACK_COST = 10
    const val SPOT_TTL_MS = 20 * 60 * 1000L
    private const val REPORT_COOLDOWN_MS = 5 * 60 * 1000L

    private lateinit var prefs: SharedPreferences

    private val _tokens = MutableStateFlow(0)
    private val _goldPacks = MutableStateFlow(0)
    private val _owned = MutableStateFlow<Map<String, Int>>(emptyMap())
    private val _spots = MutableStateFlow<List<ParkingSpot>>(emptyList())
    private val _lastTrip = MutableStateFlow<TripResult?>(null)
    private var lastReportAt = 0L

    val tokens: StateFlow<Int> = _tokens.asStateFlow()
    val goldPacks: StateFlow<Int> = _goldPacks.asStateFlow()
    val owned: StateFlow<Map<String, Int>> = _owned.asStateFlow()
    val spots: StateFlow<List<ParkingSpot>> = _spots.asStateFlow()
    val lastTrip: StateFlow<TripResult?> = _lastTrip.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("cargogotchi", Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        val json = try {
            JSONObject(prefs.getString("state", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        _tokens.value = json.optInt("tokens", 0)
        _goldPacks.value = json.optInt("gold", 0)
        lastReportAt = json.optLong("lastReportAt", 0L)

        val ownedJson = json.optJSONObject("owned")
        val ownedMap = mutableMapOf<String, Int>()
        if (ownedJson != null) {
            for (key in ownedJson.keys()) ownedMap[key] = ownedJson.optInt(key, 0)
        }
        _owned.value = ownedMap

        val spotsJson = json.optJSONArray("spots")
        val spotList = mutableListOf<ParkingSpot>()
        if (spotsJson != null) {
            for (i in 0 until spotsJson.length()) {
                val s = spotsJson.getJSONObject(i)
                spotList.add(ParkingSpot(s.getDouble("lat"), s.getDouble("lon"), s.getLong("t")))
            }
        }
        _spots.value = spotList

        val t = json.optJSONObject("lastTrip")
        _lastTrip.value = if (t == null) null else TripResult(
            score = t.optInt("score"),
            distanceKm = t.optDouble("km").toFloat(),
            durationMin = t.optInt("min"),
            harshEvents = t.optInt("harsh"),
            speedingSec = t.optInt("speeding"),
            tokens = t.optInt("tokens"),
            cargo = t.optString("cargo"),
            endedAt = t.optLong("endedAt")
        )
    }

    private fun persist() {
        val json = JSONObject()
        json.put("tokens", _tokens.value)
        json.put("gold", _goldPacks.value)
        json.put("lastReportAt", lastReportAt)

        val ownedJson = JSONObject()
        for ((k, v) in _owned.value) ownedJson.put(k, v)
        json.put("owned", ownedJson)

        val spotsJson = JSONArray()
        for (s in _spots.value) {
            spotsJson.put(JSONObject().put("lat", s.lat).put("lon", s.lon).put("t", s.reportedAt))
        }
        json.put("spots", spotsJson)

        _lastTrip.value?.let { r ->
            json.put(
                "lastTrip",
                JSONObject()
                    .put("score", r.score).put("km", r.distanceKm.toDouble()).put("min", r.durationMin)
                    .put("harsh", r.harshEvents).put("speeding", r.speedingSec)
                    .put("tokens", r.tokens).put("cargo", r.cargo).put("endedAt", r.endedAt)
            )
        }
        prefs.edit().putString("state", json.toString()).apply()
    }

    fun addTrip(r: TripResult) {
        _tokens.value += r.tokens
        _lastTrip.value = r
        persist()
    }

    /** Ouvre un pack de 3 cartes. Retourne null si le joueur n'a pas de quoi payer. */
    fun openPack(gold: Boolean): List<Crado>? {
        if (gold) {
            if (_goldPacks.value <= 0) return null
            _goldPacks.value -= 1
        } else {
            if (_tokens.value < PACK_COST) return null
            _tokens.value -= PACK_COST
        }
        val cards = if (gold) {
            listOf(Catalog.roll(Rarity.GOLD), Catalog.roll(), Catalog.roll())
        } else {
            List(3) { Catalog.roll() }
        }
        val m = _owned.value.toMutableMap()
        for (c in cards) m[c.id] = (m[c.id] ?: 0) + 1
        _owned.value = m
        persist()
        return cards
    }

    /** Signale une place libérée. Retourne false si le délai anti-abus n'est pas écoulé. */
    fun reportSpot(lat: Double, lon: Double): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastReportAt < REPORT_COOLDOWN_MS) return false
        lastReportAt = now
        val fresh = _spots.value.filter { now - it.reportedAt < SPOT_TTL_MS }
        _spots.value = fresh + ParkingSpot(lat, lon, now)
        _goldPacks.value += 1
        persist()
        return true
    }

    fun cooldownRemainingMs(): Long =
        (REPORT_COOLDOWN_MS - (System.currentTimeMillis() - lastReportAt)).coerceAtLeast(0L)
}
