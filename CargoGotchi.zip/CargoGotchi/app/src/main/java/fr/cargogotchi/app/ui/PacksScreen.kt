package fr.cargogotchi.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.cargogotchi.app.data.Crado
import fr.cargogotchi.app.data.GameRepo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PacksScreen() {
    val tokens by GameRepo.tokens.collectAsState()
    val gold by GameRepo.goldPacks.collectAsState()
    var opening by remember { mutableStateOf(false) }
    var revealed by remember { mutableStateOf<List<Crado>>(emptyList()) }
    var packNo by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    fun open(goldPack: Boolean) {
        if (opening) return
        val cards = GameRepo.openPack(goldPack) ?: return
        revealed = emptyList()
        packNo++
        opening = true
        scope.launch {
            delay(1100)
            revealed = cards
            opening = false
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Packs de cartes", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Orange)
        Text("$tokens tokens · $gold pack(s) Or", color = Mustard, fontWeight = FontWeight.Bold)

        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            when {
                opening -> ShakingPack()
                revealed.isNotEmpty() -> key(packNo) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        revealed.forEachIndexed { i, c ->
                            RevealCard(c, i * 450L, Modifier.weight(1f))
                        }
                    }
                }
                else -> Text(
                    "Gagne des tokens en conduisant, ou signale une place de parking pour un pack Or.",
                    color = Paper.copy(alpha = 0.7f)
                )
            }
        }

        Button(
            onClick = { open(false) },
            enabled = tokens >= GameRepo.PACK_COST && !opening,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Ouvrir un pack (${GameRepo.PACK_COST} tokens)", fontWeight = FontWeight.Bold) }

        Button(
            onClick = { open(true) },
            enabled = gold > 0 && !opening,
            colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Ouvrir un pack Or ($gold)", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun ShakingPack() {
    val t = rememberInfiniteTransition(label = "shake")
    val rot by t.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(tween(90), RepeatMode.Reverse),
        label = "rot"
    )
    Text("🎁", fontSize = 96.sp, modifier = Modifier.rotate(rot))
}

@Composable
private fun RevealCard(c: Crado, delayMs: Long, modifier: Modifier) {
    val scale = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs)
        scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
    }
    CradoCardView(
        c,
        modifier = modifier.graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
        }
    )
}
