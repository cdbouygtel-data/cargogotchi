package fr.cargogotchi.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import fr.cargogotchi.app.data.GameRepo
import fr.cargogotchi.app.data.TripResult
import fr.cargogotchi.app.tracking.TripBus
import fr.cargogotchi.app.tracking.TripService
import fr.cargogotchi.app.tracking.TripUi
import fr.cargogotchi.app.tracking.faceFor

private fun startTrip(ctx: Context) {
    ContextCompat.startForegroundService(
        ctx, Intent(ctx, TripService::class.java).setAction(TripService.ACTION_START)
    )
}

private fun stopTrip(ctx: Context) {
    ctx.startService(Intent(ctx, TripService::class.java).setAction(TripService.ACTION_STOP))
}

@Composable
fun TripScreen(onOpenPacks: () -> Unit) {
    val ctx = LocalContext.current
    val trip by TripBus.state.collectAsState()
    val last by GameRepo.lastTrip.collectAsState()
    val tokens by GameRepo.tokens.collectAsState()

    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    DisposableEffect(Unit) {
        val lifecycle = (ctx as ComponentActivity).lifecycle
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) overlayOk = Settings.canDrawOverlays(ctx)
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    val permissions = remember {
        buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] == true) startTrip(ctx)
    }
    fun start() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) startTrip(ctx) else launcher.launch(permissions)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Cargo-Gotchi", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text(
            "Conduis souplement, protège ta cargaison et gagne des packs de cartes.",
            color = Paper.copy(alpha = 0.75f)
        )

        if (trip.running) {
            RunningCard(trip, onStop = { stopTrip(ctx) })
        } else {
            Button(
                onClick = { start() },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) {
                Text("Démarrer le trajet", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (!overlayOk) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Bulle flottante désactivée", fontWeight = FontWeight.Bold)
                    Text("Autorise l'affichage par-dessus les autres applications pour voir ta cargaison dans Waze.")
                    OutlinedButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        )
                    }) { Text("Autoriser la bulle") }
                }
            }
        }

        last?.let { LastTripCard(it, tokens, onOpenPacks) }
    }
}

@Composable
private fun RunningCard(t: TripUi, onStop: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(faceFor(t.hp), fontSize = 72.sp)
            Text("${t.cargo.emoji} ${t.cargo.name}", fontWeight = FontWeight.Bold)
            LinearProgressIndicator(
                progress = { t.hp / 100f },
                modifier = Modifier.fillMaxWidth().height(10.dp),
                color = if (t.hp > 40) Teal else Orange
            )
            Text("État de la cargaison : ${t.hp} %")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("${t.speedKmh}", "km/h")
                Stat("%.1f".format(t.distanceM / 1000f), "km")
                Stat("${t.harshEvents}", "chocs")
            }
            Button(
                onClick = onStop,
                colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = androidx.compose.ui.graphics.Color.Black)
            ) { Text("Terminer le trajet") }
        }
    }
}

@Composable
private fun LastTripCard(r: TripResult, tokens: Int, onOpenPacks: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Bilan du dernier trajet", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Cargaison : ${r.cargo}")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("${r.score}", "score")
                Stat("%.1f".format(r.distanceKm), "km")
                Stat("${r.durationMin}", "min")
                Stat("+${r.tokens}", "tokens")
            }
            Text("${r.harshEvents} choc(s), ${r.speedingSec} s en excès de vitesse", color = Paper.copy(alpha = 0.7f))
            Text("Tu as ${tokens} tokens.")
            if (tokens >= GameRepo.PACK_COST) {
                Button(onClick = onOpenPacks) { Text("Ouvrir un pack") }
            }
        }
    }
}
