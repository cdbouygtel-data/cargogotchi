package fr.cargogotchi.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.cargogotchi.app.data.Crado
import fr.cargogotchi.app.data.Rarity

@Composable
private fun holoColor(): Color {
    val t = rememberInfiniteTransition(label = "holo")
    val hue by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2500, easing = LinearEasing), RepeatMode.Restart),
        label = "hue"
    )
    return Color.hsv(hue, 0.65f, 1f)
}

@Composable
fun CradoCardView(
    c: Crado,
    modifier: Modifier = Modifier,
    count: Int = 0,
    locked: Boolean = false
) {
    val border = when {
        locked -> Color(0xFF4A5775)
        c.rarity == Rarity.HOLO -> holoColor()
        else -> c.rarity.color
    }
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = modifier
            .background(Panel, shape)
            .border(2.dp, border, shape)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(if (locked) "❓" else c.emoji, fontSize = 40.sp)
        Text(
            if (locked) "???" else c.name,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            minLines = 2,
            maxLines = 2,
            color = Paper
        )
        Text(if (locked) "—" else c.rarity.label, fontSize = 11.sp, color = border)
        if (count > 1) Text("×$count", fontSize = 11.sp, color = Paper)
    }
}

@Composable
fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Mustard)
        Text(label, fontSize = 12.sp, color = Paper.copy(alpha = 0.7f))
    }
}
