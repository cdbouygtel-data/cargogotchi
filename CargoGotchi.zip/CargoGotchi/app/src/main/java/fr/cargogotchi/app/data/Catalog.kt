package fr.cargogotchi.app.data

import androidx.compose.ui.graphics.Color
import kotlin.random.Random

enum class Rarity(val label: String, val weight: Int, val color: Color) {
    BRONZE("Bronze", 60, Color(0xFFCD7F32)),
    SILVER("Argent", 28, Color(0xFFC3CAD6)),
    GOLD("Or", 10, Color(0xFFFFD23F)),
    HOLO("Holo", 2, Color(0xFFE040FB))
}

data class Crado(
    val id: String,
    val name: String,
    val emoji: String,
    val desc: String,
    val rarity: Rarity
)

data class Cargo(val name: String, val emoji: String)

object Catalog {

    val cards: List<Crado> = listOf(
        // Bronze
        Crado("kevin", "Kévin Frein-Sec", "🦶", "Pile à chaque feu orange. Ses passagers ont tous un torticolis.", Rarity.BRONZE),
        Crado("raymonde", "Raymonde Vomito", "🤢", "Ne conduit jamais sans sac. Surtout pas celui des autres.", Rarity.BRONZE),
        Crado("gerard", "Gérard Morve", "🤧", "Laisse des traces sur le volant. Et sur la boîte à gants.", Rarity.BRONZE),
        Crado("bernadette", "Bernadette Pustule", "🫠", "Fond doucement dans son siège dès que le soleil tape.", Rarity.BRONZE),
        Crado("jeanclaude", "Jean-Claude Nez-Qui-Coule", "👃", "Reniflement à 130 décibels dans l'habitacle.", Rarity.BRONZE),
        Crado("mireille", "Mireille Mouchoir", "🧻", "Sa voiture contient 400 mouchoirs. Aucun n'est propre.", Rarity.BRONZE),
        // Argent
        Crado("roger", "Roger Rôt-de-Gaz", "🥴", "Ouvre les fenêtres. Tout le monde sait pourquoi.", Rarity.SILVER),
        Crado("ginette", "Ginette Glaviot", "💦", "Vise le rétroviseur du voisin. Rarement à côté.", Rarity.SILVER),
        Crado("patrick", "Patrick Pied-Qui-Pue", "🦨", "Conduit en chaussettes depuis 2009.", Rarity.SILVER),
        Crado("josiane", "Josiane Jus-de-Chaussette", "🧦", "Son désodorisant s'est suicidé.", Rarity.SILVER),
        Crado("albert", "Albert Aisselle", "💨", "Lève le bras pour tourner. Les feux clignotent par pitié.", Rarity.SILVER),
        // Or
        Crado("dede", "Dédé la Dent-Creuse", "🦷", "Garde un sandwich de 2019 sous le siège. Il bouge encore.", Rarity.GOLD),
        Crado("chantal", "Chantal Croûte", "🩹", "Collectionne les pansements des autres. Pour la science.", Rarity.GOLD),
        Crado("marcel", "Marcel Moisissure", "🍄", "Cultive un potager dans le coffre. Rendement excellent.", Rarity.GOLD),
        Crado("brigitte", "Brigitte Bave", "🐌", "Laisse une traînée brillante sur tout le trajet.", Rarity.GOLD),
        // Holo
        Crado("degueu", "Le Grand Dégueulasse", "👾", "Personne ne l'a jamais vu. Tout le monde l'a senti.", Rarity.HOLO),
        Crado("mamie", "Mamie Mutante", "☣️", "Sa tarte aux pommes a développé une conscience.", Rarity.HOLO),
        Crado("capitaine", "Capitaine Crado", "🏴‍☠️", "Pirate des parkings. Gare-toi, il te vole ta place.", Rarity.HOLO)
    )

    val cargos: List<Cargo> = listOf(
        Cargo("Un bocal de piranhas", "🐟"),
        Cargo("Un gâteau de mariage", "🎂"),
        Cargo("Une pyramide de verres en cristal", "🥂"),
        Cargo("Un aquarium de poulpes", "🐙"),
        Cargo("Dix douzaines d'œufs", "🥚"),
        Cargo("Une cuve de soupe brûlante", "🍲"),
        Cargo("Un cactus très susceptible", "🌵"),
        Cargo("Une tour de crêpes", "🥞")
    )

    /** Tire une carte au hasard selon les poids de rareté, avec une rareté minimale optionnelle. */
    fun roll(min: Rarity = Rarity.BRONZE, rnd: Random = Random.Default): Crado {
        val pool = Rarity.values().filter { it.ordinal >= min.ordinal }
        var r = rnd.nextInt(pool.sumOf { it.weight })
        val rarity = pool.first {
            r -= it.weight
            r < 0
        }
        return cards.filter { it.rarity == rarity }.random(rnd)
    }
}
