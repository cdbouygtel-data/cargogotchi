package fr.cargogotchi.app

import android.app.Application
import fr.cargogotchi.app.data.GameRepo

class CargoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        GameRepo.init(this)
    }
}
