package fr.cargogotchi.app.tracking

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import fr.cargogotchi.app.MainActivity
import fr.cargogotchi.app.data.Catalog
import fr.cargogotchi.app.data.GameRepo
import fr.cargogotchi.app.data.TripResult
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Surveille la conduite (GPS + accéléromètre) pendant un trajet et alimente la bulle flottante.
 * Le score de fin de trajet (= santé de la cargaison) est converti en tokens.
 */
class TripService : Service(), SensorEventListener, LocationListener {

    companion object {
        const val ACTION_START = "fr.cargogotchi.app.START"
        const val ACTION_STOP = "fr.cargogotchi.app.STOP"
        private const val CHANNEL_ID = "trip"
        private const val NOTIF_ID = 1

        // Seuils de l'MVP. A terme : limite de vitesse réelle via OpenStreetMap.
        const val MAX_SPEED_KMH = 130f
        const val HARSH_ACCEL = 4.0f      // m/s², accélération linéaire
        const val HARSH_DECEL_GPS = 3.5f  // m/s², décélération mesurée par le GPS
        private const val HARSH_COOLDOWN_MS = 3000L
        private const val MOVING_MS = 1.4f // ~5 km/h
    }

    private lateinit var lm: LocationManager
    private lateinit var sm: SensorManager
    private var bubble: BubbleOverlay? = null

    private var running = false
    private var hp = 100f
    private var harsh = 0
    private var speedingSec = 0f
    private var distanceM = 0f
    private var lastLoc: Location? = null
    private var lastSpeedMs = 0f
    private var lastHarshAt = 0L
    private var startedAt = 0L
    private var cargo = Catalog.cargos.random()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> finishTrip()
            else -> startTrip()
        }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startTrip() {
        if (running) return
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        )

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
        } catch (e: Exception) {
            // Permission de localisation absente ou GPS indisponible
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        running = true
        hp = 100f
        harsh = 0
        speedingSec = 0f
        distanceM = 0f
        lastLoc = null
        lastSpeedMs = 0f
        cargo = Catalog.cargos.random()
        startedAt = System.currentTimeMillis()

        sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }

        if (Settings.canDrawOverlays(this)) {
            bubble = BubbleOverlay(this).also { it.show() }
        }
        publish()
    }

    private fun finishTrip() {
        if (!running) {
            stopSelf()
            return
        }
        running = false
        cleanup()

        val now = System.currentTimeMillis()
        val durationMin = ((now - startedAt) / 60000L).toInt()
        val km = distanceM / 1000f
        val score = hp.toInt().coerceIn(0, 100)
        val tokens = if (distanceM < 200f) {
            0
        } else {
            min(50, max(1, (score / 100f * (km * 2f + durationMin / 2f)).roundToInt()))
        }
        GameRepo.addTrip(
            TripResult(
                score = score,
                distanceKm = km,
                durationMin = durationMin,
                harshEvents = harsh,
                speedingSec = speedingSec.toInt(),
                tokens = tokens,
                cargo = cargo.name,
                endedAt = now
            )
        )
        TripBus.state.value = TripUi()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup() {
        try {
            lm.removeUpdates(this)
        } catch (e: Exception) {
        }
        sm.unregisterListener(this)
        bubble?.hide()
        bubble = null
    }

    override fun onDestroy() {
        if (running) {
            running = false
            cleanup()
            TripBus.state.value = TripUi()
        }
        super.onDestroy()
    }

    // --- Capteurs ---------------------------------------------------------------------------

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        val magnitude = sqrt(x * x + y * y + z * z)
        if (magnitude > HARSH_ACCEL && lastSpeedMs > MOVING_MS) recordHarsh()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onLocationChanged(location: Location) {
        val prev = lastLoc
        val speedMs = if (location.hasSpeed()) location.speed else 0f

        if (prev != null) {
            val dt = (location.time - prev.time) / 1000f
            if (dt > 0f && dt < 10f) {
                if (speedMs > 1f) distanceM += prev.distanceTo(location)
                val decel = (lastSpeedMs - speedMs) / dt
                if (decel > HARSH_DECEL_GPS && lastSpeedMs > MOVING_MS) recordHarsh()
                if (speedMs * 3.6f > MAX_SPEED_KMH) {
                    speedingSec += dt
                    hp -= 0.4f * dt
                }
            }
        }
        lastLoc = location
        lastSpeedMs = speedMs
        hp = hp.coerceIn(0f, 100f)
        publish()
    }

    // Requis explicitement pour les API < 30
    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun recordHarsh() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastHarshAt < HARSH_COOLDOWN_MS) return
        lastHarshAt = now
        harsh++
        hp = max(0f, hp - 8f)
        publish()
    }

    private fun publish() {
        val hpInt = hp.toInt()
        TripBus.state.value = TripUi(
            running = true,
            hp = hpInt,
            speedKmh = (lastSpeedMs * 3.6f).toInt(),
            distanceM = distanceM,
            harshEvents = harsh,
            cargo = cargo,
            startedAt = startedAt
        )
        bubble?.update(faceFor(hpInt), cargo.emoji, hpInt)
    }

    // --- Notification -----------------------------------------------------------------------

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Trajet en cours", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TripService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Cargo-Gotchi")
            .setContentText("Protège ta cargaison : conduis souplement")
            .setContentIntent(open)
            .addAction(0, "Terminer le trajet", stop)
            .setOngoing(true)
            .build()
    }
}
