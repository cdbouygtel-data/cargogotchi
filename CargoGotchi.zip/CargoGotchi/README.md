# Cargo-Gotchi (MVP Android)

Application compagnon de conduite gamifiée : conduis souplement pour protéger une cargaison absurde,
gagne des tokens, ouvre des packs de cartes « crados » et signale les places de parking libérées.

## Lancer le projet
1. Ouvre le dossier dans **Android Studio** (Koala ou plus récent, JDK 17). Il génère le wrapper Gradle tout seul.
2. Lance sur un téléphone réel (le GPS et les capteurs ne marchent pas bien sur émulateur).
3. Au premier trajet : accepte la localisation et les notifications, puis « Autoriser la bulle » pour l'affichage par-dessus Waze.

## Ce qui est dans le MVP
- **Trajet** : service au premier plan (GPS + accéléromètre), détection des chocs et des excès de vitesse,
  score = santé de la cargaison, bulle flottante déplaçable, bilan en tokens.
- **Packs** : 10 tokens = 3 cartes, animation de déchirure, raretés Bronze / Argent / Or / Holo.
  Le pack Or garantit au moins une carte Or.
- **Collection** : 17 cartes originales, fiche détaillée, progression par rareté.
- **Parking** : bouton « Je libère ma place » (+1 pack Or, délai de 5 min entre deux signalements),
  liste des places récentes (20 min) et ouverture dans l'app de cartes.

## Pas encore fait (à prévoir)
- **Backend** pour partager les places entre joueurs (aujourd'hui stockées sur le téléphone, voir `GameRepo.reportSpot`).
- Mode « Snake » (guidage vers les places), carte OpenStreetMap.
- Limite de vitesse réelle par route (aujourd'hui fixe à 130 km/h dans `TripService`).
- Anti-triche (vérifier qu'on est bien en voiture, pas dans le train), calibrage des seuils sur des vrais trajets.
- Cartes avantages partenaires, boutique cosmétique, offres assureurs.
- Icône définitive, sons, animations de la bulle quand la cargaison prend un choc.

## Points de vigilance
- Google Play demande une justification pour la localisation en arrière-plan / service de localisation
  et pour la permission « affichage par-dessus d'autres applis ».
- Aucune interaction n'est prévue pendant la conduite : tout se joue à l'arrêt.
